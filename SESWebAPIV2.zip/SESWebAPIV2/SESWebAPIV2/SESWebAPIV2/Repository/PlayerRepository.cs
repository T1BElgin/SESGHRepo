﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SESWebAPIV2.Models;
using SESWebAPIV2.APIServices;

namespace SESWebAPIV2.Repository
{
    public class PlayerRepository : IPlayerRepository<int, Player>
    {
        private readonly MatchContext _context;
        private readonly ILogger<MatchRepository> _logger;

        public PlayerRepository(MatchContext context, ILogger<MatchRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<Player> Add(Player item)
        {
            try
            {
                _context.Players.Add(item);
                await _context.SaveChangesAsync();
                return item;
            }
            catch (Exception exception)
            {
                _logger.LogError(exception.Message);
                _logger.LogError("----" + DateTime.Now.ToString());
            }
            return null;
        }

        public async Task<Player> Delete(int key)
        {
            try
            {
                var item = await Get(key);
                _context.Players.Remove(item);
                await _context.SaveChangesAsync();
                return item;
            }
            catch (Exception e)
            {
                _logger.LogError("Error in Deleting Player");
            }
            return null;
        }

        public async Task<Player> Get(int key)
        {
            try
            {
                var item = _context.Players.FirstOrDefault(p => p.Id == key);
                return item;
            }
            catch (Exception e)
            {
                _logger.LogError("Error in Retrieving Player Details");
            }
            return null;
        }

        public async Task<ICollection<Player>> GetAll()
        {
            return _context.Players.ToList();
        }

        public async Task<Player> Update(Player item)
        {
            try
            {
                var player = await Get(item.Id);
                // DO NOT ADD ID
                player.FullName = item.FullName;
                player.JerseyNumber = item.JerseyNumber;
                player.FieldPosition = item.FieldPosition;
                player.TeamId = item.TeamId;
                // Double check the teamName attribute
                await _context.SaveChangesAsync();
                return item;
            }
            catch (Exception e)
            {
                _logger.LogError("Error in Updating Player Details");
            }
            return null;
        }
    }
}

