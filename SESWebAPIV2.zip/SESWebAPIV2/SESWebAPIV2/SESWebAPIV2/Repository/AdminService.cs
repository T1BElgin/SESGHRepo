﻿using Microsoft.Extensions.Logging;
using SESWebAPIV2.Models;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace SESWebAPIV2.Repository
{
    public class AdminService : IAdmin
    {
        private readonly MatchContext _context;
        private readonly ILogger<AdminService> _logger;

        public AdminService(MatchContext context, ILogger<AdminService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public AdminLoginDTO Login(AdminLoginDTO admin)
        {
            var dbAdmin = _context.Admins.FirstOrDefault(adm => admin.Username == admin.Username);
            if (dbAdmin == null)
                return null;
            admin.Password = "";
            return admin;
        }
    }
}
