﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SESWebAPIV2.Models;
using SESWebAPIV2.Repository;

namespace SESWebAPIV2.APIServices
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IAdmin _adminRepository;
        public AdminController(IAdmin adminRepository)
        {
            _adminRepository = adminRepository;
        }
        [HttpPost]
        [Route("Login")]
        public ActionResult<AdminLoginDTO> Login(AdminLoginDTO admin)
        {
            var resultAdmin = _adminRepository.Login(admin);

            if (resultAdmin != null)
                return Ok(resultAdmin);

            admin.Password = "";
            return Unauthorized(admin);
        }
        //[HttpPost]
        //[Route("Register")]
        //public ActionResult<AdminLoginDTO> Register(AdminDTO admin)
        //{
        //    var resultAdmin = _adminRepository.Register(admin);
        //    if (resultAdmin != null)
        //        return Ok(resultAdmin);
        //    admin.Password = "";
        //    return BadRequest(admin);
        //}
    }
}
