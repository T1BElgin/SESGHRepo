﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SESWebAPIV2.Models
{
    public class Match
    {
        [Key]
        public int MatchId { get; set; }

        public string TeamA { get; set; }

        public string TeamAURL { get; set; }

        public string TeamB { get; set; }

        public string TeamBURL { get; set; }

        public string Date { get; set; }

        public string Time { get; set; }

        public string Location { get; set; }

        public virtual ICollection<Team> Teams { get; set; }
        //[Key]
        //public int Id { get; set; }
        //public string Name { get; set; }
        //public int Capacity { get; set; }

    }
}
